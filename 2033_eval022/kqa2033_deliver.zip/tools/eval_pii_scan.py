# -*- coding: utf-8 -*-
"""eval-pii-scan：全仓扫描真实格式的手机号 / 邮箱 / 身份证（AC2 要求通过）。

宽松正则、宁可误报：占位写法（010-XXXX-XXXX、example.invalid）不算命中。
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAT = {
    "手机号": re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"),
    "邮箱": re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"),
    "身份证": re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)"),
}
SKIP_EXT = {".sqlite3", ".png", ".jpg", ".pdf", ".pyc"}
SAFE = ("example.invalid", "xxx", "XXXX")


def scan(root=HERE):
    hits = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d != "__pycache__"]
        for fn in fns:
            if os.path.splitext(fn)[1].lower() in SKIP_EXT:
                continue
            p = os.path.join(dp, fn)
            try:
                t = open(p, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            for kind, rx in PAT.items():
                for m in rx.finditer(t):
                    seg = m.group(0)
                    if any(s in seg for s in SAFE) or "XXXX" in t[max(0, m.start() - 8):m.end()]:
                        continue
                    hits.append({"file": os.path.relpath(p, root), "kind": kind, "value": seg[:32]})
    return hits


def main():
    h = scan()
    for x in h[:20]:
        print("PII", x)
    print("hits=%d" % len(h))
    print("PII %s" % ("PASS" if not h else "FAIL"))
    return 0 if not h else 1


if __name__ == "__main__":
    sys.exit(main())
