# -*- coding: utf-8 -*-
"""本地桩评审模型：模拟「本地部署的评审模型」，让整条链路可离线复现。

它必须真的做四件事，否则测不出东西：
 1. 从被测输出里**截取真实片段**作为 evidence_quote（不是编的）；
 2. 能出 yes / partial / no 三档，且**只按提示词给的要点清单 + 被测输出**判定
    （绝不看人工标注 —— 那是「自己判自己」）；
 3. 识别否定：「不涉及脱敏」「暂不脱敏」不算命中。这条很关键，
    否则关键词匹配会把否定句算成覆盖，是评测里最常见的一类假阳性；
 4. 支持注入缺陷（`mode="bad_quote"`）—— 故意给一条原文里找不到的 quote，
    用来验证「回查不到按 no 处理」这条规则真的生效。

换真实模型时只替换 `judge_prompt()` 的实现，上游 scorer 与所有测试不动。
"""
import json
import re

# 要点判定用的「覆盖信号」：按要点描述里的关键词表选择信号组
SIGNAL = (
    (("时限", "响应"), ("工作日", "个工作日内", "天内", "小时", "响应")),
    (("脱敏",), ("脱敏", "掩码", "去标识")),
    (("留痕", "审计"), ("留痕", "审计日志", "操作记录")),
    (("复盘", "回顾"), ("复盘", "回顾")),
    (("回滚", "回退"), ("回滚", "回退")),
    (("幂等",), ("幂等", "不重复生效")),
)

# 否定词：紧邻信号词之前出现，说明这不是承诺
# 「另行约定/待定」不是「含糊」，是明确推脱 —— 归入否定，判 no 而不是 partial。
NEG = ("不涉及", "不承诺", "不提供", "暂不", "不再", "无需", "无须", "未提供", "不做", "不含",
       "另行约定", "另议", "待定")
# 含糊表述：无具体数值/范围时最多判 partial
VAGUE = ("尽快", "待确认", "择机", "酌情")
# 明确的范围限定词：出现即认为覆盖到位
SCOPE = ("送模型前", "入库前", "导出前", "全流程", "全程", "均", "所有")

NUM = re.compile(r"\d")


def _sentences(text: str) -> list:
    return [s.strip() for s in re.split(r"[。；;！!\n]", text) if s.strip()]


def _has_neg(text: str, pos: int) -> bool:
    """信号词前 6 个字符内是否出现否定词。"""
    head = text[max(0, pos - 6):pos]
    return any(n in head for n in NEG)


def _signals_for(desc: str) -> tuple:
    for keys, sig in SIGNAL:
        if any(k in desc for k in keys):
            return sig
    return (desc[:4],)


def _judge_point(desc: str, output: str) -> tuple:
    """返回 (hit, quote)。只看 desc 与 output，不看任何人工标注。"""
    sig = _signals_for(desc)
    sents = _sentences(output)
    best = ("no", "")
    for s in sents:
        hit_pos = None
        for x in sig:
            i = s.find(x)
            if i >= 0:
                hit_pos = i
                break
        if hit_pos is None:
            continue
        if _has_neg(s, hit_pos):
            continue                                   # 否定句不算命中
        hit = _yes_or_partial(desc, s)
        if hit == "yes":
            return "yes", s                            # 直接取最好的
        if best[0] == "no":
            best = (hit, s)
    return best


def _yes_or_partial(desc: str, sent: str) -> str:
    """句子命中信号后，再判是「完整覆盖」还是「部分覆盖」。"""
    vague = any(v in sent for v in VAGUE)
    has_num = bool(NUM.search(sent))
    has_scope = any(x in sent for x in SCOPE)
    # 要点要求「覆盖送模型前的环节」
    if "送模型" in desc:
        covered = ("送模型前" in sent or "再送模型" in sent or "入库前" in sent
                   or "全流程" in sent or "全程" in sent)
        if covered:
            return "yes"
        # 只提「方案/待确认」而没有实际脱敏动作 -> 视为未覆盖
        action = any(a in sent for a in ("做脱敏", "进行脱敏", "已脱敏", "脱敏处理", "脱敏后", "脱敏再"))
        return "partial" if action else "no"
    if vague and not has_num:
        return "partial"
    if has_num or has_scope:
        return "yes"
    return "partial"


def judge_prompt(prompt: str, mode: str = "normal") -> str:
    """解析提示词里的要点清单与被测输出，逐条产出结论（模拟模型返回 JSON）。"""
    m = re.search(r"## 要点清单\n(.*?)\n\n## 被测输出\n", prompt, re.S)
    m2 = re.search(r"## 被测输出\n(.*)$", prompt, re.S)
    if not m or not m2:
        return "{}"
    listing = [l for l in m.group(1).splitlines() if "|" in l]
    output = m2.group(1).strip()
    results = []
    for line in listing:
        pid, desc = [x.strip() for x in line.split("|", 1)]
        if "金额" in desc:                              # 金额由程序接管，模型一律 no
            results.append({"point_id": pid, "hit": "no", "evidence_quote": ""})
            continue
        hit, quote = _judge_point(desc, output)
        if mode == "bad_quote" and hit != "no":
            quote = "（此句在原文中并不存在，用于验证回查机制）"
        results.append({"point_id": pid, "hit": hit, "evidence_quote": quote})
    return json.dumps({"results": results}, ensure_ascii=False)


def make_caller(mode: str = "normal"):
    def _caller(prompt: str) -> str:
        return judge_prompt(prompt, mode=mode)
    return _caller
