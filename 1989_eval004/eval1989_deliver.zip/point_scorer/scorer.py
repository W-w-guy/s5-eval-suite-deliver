# -*- coding: utf-8 -*-
"""score_points(case, output) -> PointScore 的核心实现。

三种 match 方式：
  · keyword      任一关键词组命中即算命中（支持同义词表）
  · semantic     调用本地评审模型，逐条输出 {point_id, hit, evidence_quote}
                 evidence_quote 回查不到原文 -> 该条强制记 no（AC2）
  · exact_field  结构化字段严格相等；金额类要点只允许走这里（评审模型不判金额）

两条一票否决（AC3）：
  · forbidden_points 任一命中 -> violation=True、passed=False，即使得分 100% 也不通过
  · must=true 的要点未命中 -> passed=False

稳定性：
  同一输出评 3 次取多数；3 次结论不完全一致的用例打 judge_unstable=True。
"""
import json
import re

from . import model as model_mod

PROMPT_VERSION = "v1.2.0"
JUDGE_ROUNDS = 3

# ---- 同义词表：keyword 方式用 ----
SYNONYMS = {
    "首次响应": ["首次响应", "首响", "初次响应", "第一次响应"],
    "工作日": ["工作日", "工作天"],
    "复盘": ["复盘", "回顾", "事后总结"],
    "复核": ["复核", "二次审核", "复审"],
    "脱敏": ["脱敏", "掩码", "去标识"],
    "回滚": ["回滚", "回退", "复原"],
    "幂等": ["幂等", "重复提交不重复生效"],
    "留痕": ["留痕", "审计日志", "操作记录"],
}

HIT_WEIGHT = {"yes": 1.0, "partial": 0.5, "no": 0.0}


class PointScore(dict):
    """用 dict 承载结果，字段固定。

    为什么不用 dataclass：交付物要能被 json.dumps 直接落盘，
    dict 少一层 to_dict()，且测试可以直接断言字段。
    """


def _norm(s: str) -> str:
    # 只做空白归一，不改字 —— evidence_quote 必须「逐字」可查
    return re.sub(r"\s+", "", s or "")


def _quote_in(quote: str, output: str) -> bool:
    """evidence_quote 是否逐字出现在被测输出中（忽略空白差异，但不忽略字符）。"""
    q = _norm(quote)
    return bool(q) and q in _norm(output)


# 否定词：紧邻关键词之前出现，说明这句是「不提供/不涉及」，不能算命中。
# 这是关键词匹配最典型的假阳性：「本方案不涉及脱敏」里确实有「脱敏」两个字。
NEG_WORDS = ("不涉及", "不承诺", "不提供", "暂不", "不再", "无需", "无须", "未提供", "不做", "不含")


def _kw_hit(point: dict, output: str) -> tuple:
    """返回 (hit, matched_term)。任一关键词组命中即命中；但紧跟否定的命中不算。"""
    groups = point.get("keyword_groups") or []
    low = output.lower()
    for grp in groups:
        for kw in grp:
            for term in SYNONYMS.get(kw, [kw]):
                start = 0
                while True:
                    i = low.find(term.lower(), start)
                    if i < 0:
                        break
                    if not any(n in low[max(0, i - 6):i] for n in NEG_WORDS):
                        return "yes", term
                    start = i + 1
    return "no", ""


def _exact_hit(point: dict, output) -> tuple:
    """结构化字段严格相等。output 可以是 dict（字段表）或纯文本。"""
    field = point.get("field")
    expect = point.get("expected_value")
    if not isinstance(output, dict):
        return "no", ""
    got = output.get(field)
    # 严格相等：不做大小写/空白/四舍五入的宽松处理（金额类必须这样）
    return ("yes" if got == expect else "no"), ("" if got is None else str(got))


def build_semantic_prompt(points: list, output: str, prompt_path: str) -> str:
    with open(prompt_path, encoding="utf-8") as fh:
        tpl = fh.read()
    listing = "\n".join("%s | %s" % (p["point_id"], p["desc"]) for p in points)
    return tpl + "\n\n## 要点清单\n" + listing + "\n\n## 被测输出\n" + output + "\n"


def parse_judge(raw: str) -> dict:
    """解析评审模型输出。解析失败返回 {}（调用方按 no 处理，并计入 unstable）。"""
    if not raw:
        return {}
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        return {}
    try:
        obj = json.loads(m.group(0))
    except Exception:
        return {}
    out = {}
    for r in (obj.get("results") or []):
        pid = r.get("point_id")
        hit = (r.get("hit") or "").lower()
        if pid and hit in HIT_WEIGHT:
            out[pid] = {"hit": hit, "evidence_quote": r.get("evidence_quote") or ""}
    return out


def judge_once(points: list, output: str, prompt_path: str, caller=None) -> dict:
    prompt = build_semantic_prompt(points, output, prompt_path)
    raw = caller(prompt) if caller else model_mod.call(prompt)
    return parse_judge(raw)


def _majority(rounds: list, pids: list) -> tuple:
    """3 轮取多数。返回 ({pid: {hit, evidence_quote}}, unstable)。

    多数规则：出现次数最多的 hit 获胜；平票时取「更保守」的那个（no > partial > yes）——
    评分器宁可低估也不该高估命中率，否则会放过不合格的输出。

    quote 必须与采纳的结论**来自同一轮**，不能拿 A 轮的结论配 B 轮的原文：
    否则「回查 evidence_quote」验的是一条模型根本没为这个结论引用过的句子。
    """
    order = {"no": 0, "partial": 1, "yes": 2}
    out, unstable = {}, False
    for pid in pids:
        votes = []
        for r in rounds:
            cell = r.get(pid) or {}
            votes.append((cell.get("hit", "no"), cell.get("evidence_quote") or ""))
        if len({v[0] for v in votes}) > 1:
            unstable = True
        cnt = {}
        for h, _q in votes:
            cnt[h] = cnt.get(h, 0) + 1
        top = max(cnt.values())
        cands = [h for h, c in cnt.items() if c == top]
        final = sorted(cands, key=lambda x: order[x])[0]
        quote = next((q for h, q in votes if h == final), "")
        out[pid] = {"hit": final, "evidence_quote": quote}
    return out, unstable


def score_points(case: dict, output, caller=None, prompt_path=None, rounds=JUDGE_ROUNDS) -> PointScore:
    """主入口。

    case 结构：
      {"case_id", "points": [{point_id, desc, weight, must, match, ...}],
       "forbidden_points": [{point_id, desc, keyword_groups}]}
    output：纯文本（keyword/semantic）或 dict（exact_field 的字段表）
    """
    prompt_path = prompt_path or case.get("_prompt_path")
    pts = case.get("points") or []
    res = PointScore({
        "case_id": case.get("case_id"),
        "prompt_version": PROMPT_VERSION,
        "points": [],
        "score": 0.0,
        "violation": False,
        "violation_points": [],
        "must_missed": [],
        "passed": False,
        "judge_unstable": False,
        "judge_rounds": rounds,
        "evidence_rejected": [],
    })

    sem = [p for p in pts if p.get("match") == "semantic"]
    sem_hits, unstable = {}, False
    if sem:
        pids = [p["point_id"] for p in sem]
        rnd = [judge_once(sem, output if isinstance(output, str) else json.dumps(output, ensure_ascii=False),
                          prompt_path, caller) for _ in range(rounds)]
        sem_hits, unstable = _majority(rnd, pids)
    res["judge_unstable"] = unstable

    text = output if isinstance(output, str) else json.dumps(output, ensure_ascii=False)
    total_w = hit_w = 0.0
    for p in pts:
        pid = p["point_id"]
        m = p.get("match")
        if m == "keyword":
            hit, ev = _kw_hit(p, text)
        elif m == "exact_field":
            hit, ev = _exact_hit(p, output)
        elif m == "semantic":
            cell = sem_hits.get(pid) or {"hit": "no", "evidence_quote": ""}
            hit, ev = cell["hit"], cell["evidence_quote"]
            # AC2：回查 evidence_quote，查不到强制降级为 no（判 yes/partial 必须有原文）
            if hit in ("yes", "partial") and not _quote_in(ev, text):
                res["evidence_rejected"].append({"point_id": pid, "quote": ev, "judged": hit})
                hit, ev = "no", ""
        else:
            raise ValueError("未知 match 方式：%r（允许 keyword/semantic/exact_field）" % m)
        w = float(p.get("weight", 1.0))
        total_w += w
        hit_w += w * HIT_WEIGHT[hit]
        if p.get("must") and hit != "yes":
            res["must_missed"].append(pid)
        res["points"].append({"point_id": pid, "match": m, "hit": hit,
                              "weight": w, "must": bool(p.get("must")),
                              "evidence_quote": ev})

    # forbidden_points：一票否决（AC3）
    for fp in (case.get("forbidden_points") or []):
        h, term = _kw_hit(fp, text)
        if h == "yes":
            res["violation"] = True
            res["violation_points"].append({"point_id": fp.get("point_id"),
                                            "desc": fp.get("desc"), "matched": term})

    res["score"] = round(hit_w / total_w, 6) if total_w else 0.0
    # passed 的三个条件：无违规、无 must 漏点、且 score>0
    res["passed"] = (not res["violation"]) and (not res["must_missed"]) and res["score"] > 0
    return res
