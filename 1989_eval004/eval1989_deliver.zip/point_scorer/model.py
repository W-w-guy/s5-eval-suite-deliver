# -*- coding: utf-8 -*-
"""评审模型调用层：地址只从环境变量读取，且强制本机/内网。

单子写明「评审模型地址从环境变量读取，禁止使用境外接口」。
只写在 README 里不算实现 —— 有人把 env 改成 api.openai.com 就绕过去了。
所以这里把校验做进调用路径：不合格地址在发请求前就抛 RejectEndpoint，绝不降级到公有云。
"""
import json
import os
import urllib.error
import urllib.parse
import urllib.request

ENV_URL = "POINT_JUDGE_URL"
TIMEOUT_ENV = "POINT_JUDGE_TIMEOUT"

# 只允许本机、内网、容器网络名。公网 IP 与境外域名一律拒绝。
ALLOWED_PREFIX = ("127.", "10.", "192.168.", "172.", "::1", "localhost")
ALLOWED_SUFFIX = (".local", ".internal", ".lan", ".svc", "host.docker.internal")


class RejectEndpoint(RuntimeError):
    """评审模型地址不合规（境外 / 公网 / 协议不支持 / 未设置）。"""


def check_endpoint(url: str | None = None) -> str:
    """校验并返回规范化的 URL。不合规抛 RejectEndpoint。

    故意把「未设置」也当成错误：静默 fallback 到某个默认公有云是最危险的行为。
    """
    url = os.environ.get(ENV_URL, "") if url is None else url
    if not url:
        raise RejectEndpoint("%s 未设置（禁止使用默认/境外评审模型）" % ENV_URL)
    p = urllib.parse.urlparse(url)
    if p.scheme not in ("http", "https"):
        raise RejectEndpoint("协议不支持：%r" % p.scheme)
    host = (p.hostname or "").lower()
    if not host:
        raise RejectEndpoint("无法解析主机名：%r" % url)
    ok = host.startswith(ALLOWED_PREFIX) or host.endswith(ALLOWED_SUFFIX)
    if not ok:
        raise RejectEndpoint(
            "拒绝非本机/内网评审模型地址：%s（单子要求禁止境外接口）。"
            "允许 127.* / 10.* / 192.168.* / 172.* / localhost / *.internal 等。" % host)
    return url


def timeout() -> float:
    try:
        return float(os.environ.get(TIMEOUT_ENV, "20"))
    except ValueError:
        return 20.0


def call(prompt: str, url: str | None = None, temperature: float = 0.0) -> str:
    """调用本地评审模型，返回原始文本。

    temperature 固定传 0（单子要求），但**不依赖**服务端真的遵守 ——
    稳定性靠「3 次取多数 + judge_unstable 标记」在客户端保证。
    """
    target = check_endpoint(url)
    body = json.dumps({"prompt": prompt, "temperature": temperature, "max_tokens": 1200}).encode("utf-8")
    req = urllib.request.Request(target.rstrip("/") + "/generate", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    # 本地模型不经代理：本机 Clash 会把 127.0.0.1 也送进代理（踩过）
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=timeout()) as r:
            raw = r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        raise RuntimeError("评审模型 HTTP %s" % e.code)
    except Exception as e:
        raise RuntimeError("%s: %s" % (type(e).__name__, e))
    try:
        obj = json.loads(raw)
    except Exception:
        return raw
    for k in ("text", "output", "response", "content"):
        if isinstance(obj, dict) and k in obj:
            return str(obj[k])
    return raw
