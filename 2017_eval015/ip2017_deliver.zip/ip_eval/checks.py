# -*- coding: utf-8 -*-
"""三项程序化检查：金句逐字、时间戳单调且不超总时长、摘要数字必须出现在转写稿。

每条检查都写成「返回 (OK/FAIL, 明细)」，并且**必须能被正反夹具分别验证**——
只测通过、不测失败，等于没测。
"""
import re

TS = re.compile(r"\[(\d{2}):(\d{2})\]")


def parse_ts(s: str) -> int:
    m = re.match(r"^(\d{1,2}):(\d{2})$", (s or "").strip().strip("[]"))
    if not m:
        return -1
    return int(m.group(1)) * 60 + int(m.group(2))


def norm(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


# ---------- 1. 金句必须逐字出自转写稿 ----------
def check_quotes(quotes: list, transcript: str) -> dict:
    t = norm(transcript)
    bad = [q for q in (quotes or []) if not q or norm(q) not in t]
    return {"ok": not bad, "checked": len(quotes or []), "bad": bad,
            "reason": ("金句在各处逐字可查" if not bad
                       else "有 %d 条金句在转写稿中查不到原文" % len(bad))}


# ---------- 2. 时间戳单调递增且不超过总时长 ----------
def check_timestamps(ts_list: list, duration_sec: int) -> dict:
    """ts_list 为字符串或秒数列表。检查单调递增、不超总时长、无重复。"""
    secs = []
    for x in (ts_list or []):
        # 支持三种形态：秒数、形如 "03:20" 的字符串、以及 {"ts": "03:20"} 的章节对象
        # （初版只处理前两种，章节对象 str() 出来是 "{'ts': ...}" —— 解析必失败，
        #   于是 18 条摘要用例全被判「存在无法解析的时间戳」，实测通过率 0）
        if isinstance(x, int):
            secs.append(x)
        elif isinstance(x, dict):
            secs.append(parse_ts(str(x.get("ts") or "")))
        else:
            secs.append(parse_ts(str(x)))
    problems = []
    if any(s < 0 for s in secs):
        problems.append("存在无法解析的时间戳")
    if secs != sorted(secs):
        problems.append("时间戳非单调递增")
    if len(set(secs)) != len(secs):
        problems.append("存在重复时间戳")
    over = [s for s in secs if s > duration_sec]
    if over:
        problems.append("有 %d 个时间戳超过总时长 %d 秒" % (len(over), duration_sec))
    return {"ok": not problems, "problems": problems, "checked": len(secs),
            "reason": ("时间戳单调、无重复、均不超总时长" if not problems else "；".join(problems))}


# ---------- 3. 摘要中的数字必须出现在转写稿中 ----------
def check_summary_numbers(summary: str, transcript: str) -> dict:
    nums = re.findall(r"\d+(?:\.\d+)?", summary or "")
    tn = set(re.findall(r"\d+(?:\.\d+)?", transcript or ""))
    bad = [n for n in nums if n not in tn]
    return {"ok": not bad, "checked": len(nums), "bad": bad,
            "reason": ("摘要中的 %d 个数字都能在转写稿中找到" % len(nums) if not bad
                       else "有 %d 个数字不在转写稿中：%s" % (len(bad), bad[:5]))}


# ---------- 汇总 ----------
def check_summary_output(case: dict, output: dict, transcript: str) -> dict:
    """对一条摘要用例的完整输出做三项检查。output = {summary, sections, quotes}"""
    r1 = check_quotes(output.get("quotes") or [], transcript)
    r2 = check_timestamps(output.get("sections") or [], case["duration_sec"])
    r3 = check_summary_numbers(output.get("summary") or "", transcript)
    ok = r1["ok"] and r2["ok"] and r3["ok"]
    return {"ok": ok, "quotes": r1, "timestamps": r2, "numbers": r3,
            "reason": "；".join(x["reason"] for x in (r1, r2, r3) if not x["ok"]) or "三项检查全部通过"}


def check_outline_output(case: dict, output: dict) -> dict:
    """提纲用例：开场白 + 3–5 个板块 + 每板块 2 个追问 + 不碰不谈话题。"""
    problems = []
    if not (output.get("opening") or "").strip():
        problems.append("缺开场白")
    secs = output.get("sections") or []
    if not (3 <= len(secs) <= 5):
        problems.append("板块数 %d 不在 3–5" % len(secs))
    for i, s in enumerate(secs):
        if len(s.get("followups") or []) != 2:
            problems.append("第 %d 个板块的追问数 != 2" % (i + 1))
        if not (s.get("title") or "").strip():
            problems.append("第 %d 个板块缺标题" % (i + 1))
    off = case.get("off_limit_topic") or ""
    body = " ".join([output.get("opening") or ""] +
                    [s.get("title") or "" for s in secs] +
                    [f for s in secs for f in (s.get("followups") or [])])
    if off and off in body:
        problems.append("在不谈话题「%s」上展开了" % off)
    return {"ok": not problems, "problems": problems,
            "reason": "；".join(problems) if problems else "提纲结构合规且未碰不谈话题"}
