# -*- coding: utf-8 -*-
"""评测 runner。

被测工具（echo mock）：
  · 摘要：从转写稿里抽首段做摘要（截到 300 字内）、按 [mm:ss] 抽章节、挑 3 句金句（原句）
  · 提纲：按嘉宾背景生成开场白 + 3 个板块 × 2 追问，且刻意绕开不谈话题

破坏开关（用于证明检查脚本真的有效）：
  --break-quote     金句改写一个字（应判失败）
  --break-timestamp 时间戳乱序（应判失败）
  --break-number    摘要里编一个数字（应判失败）
"""
import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from ip_eval import checks as C

DATA = os.path.join(HERE, "data", "cases.jsonl")
REPORTS = os.path.join(HERE, "reports")
SUMMARY_MAX = 300


def load_cases():
    return [json.loads(l) for l in open(DATA, encoding="utf-8") if l.strip()]


def read_transcript(c):
    return open(os.path.join(HERE, c["input_file"]), encoding="utf-8").read()


def summarize(text):
    """≤300 字摘要：取前若干句，保留原文数字（不新增）。"""
    body = re.sub(r"\[\d{2}:\d{2}\]", "", text)
    sents = [s.strip() for s in re.split(r"[。！？\n]", body) if s.strip()]
    out = ""
    for s in sents:
        if len(out) + len(s) + 1 > SUMMARY_MAX:
            break
        out += s + "。"
    return out[:SUMMARY_MAX]


def extract_sections(text):
    """按转写稿里出现的时间戳抽章节（单调递增，天然不超总时长）。"""
    secs = []
    for m in re.finditer(r"\[(\d{2}):(\d{2})\]\s*([^：\n]{0,20})[：:]\s*(.{0,24})", text):
        ts = "%s:%s" % (m.group(1), m.group(2))
        title = (m.group(3) or "").strip() or (m.group(4) or "").strip()[:16]
        if title and (not secs or secs[-1]["ts"] != ts):
            secs.append({"ts": ts, "title": title})
    # 去重并按时间排序（原稿本身有序，这里只是保证）
    seen, out = set(), []
    for s in sorted(secs, key=lambda x: C.parse_ts(x["ts"])):
        if s["ts"] in seen:
            continue
        seen.add(s["ts"])
        out.append(s)
    return out[:10]


def pick_quotes(text, k=3):
    """挑「嘉宾说的、较短的完整句」作为金句（必须是原句，不改写）。"""
    cand = []
    for line in text.split("\n"):
        m = re.match(r"\[\d{2}:\d{2}\]\s*([^：]{1,20})[：:]\s*(.+)", line)
        if not m:
            continue
        who, said = m.group(1), m.group(2).strip()
        if "主持人" in who:
            continue
        if 18 <= len(said) <= 60:
            cand.append(said)
    return cand[:k]


def outline(c):
    guest = c["guest"]
    topic = c["topic"]
    off = c.get("off_limit_topic") or ""
    secs = [
        {"title": "%s 的起步经历" % topic, "followups": ["当时的第一步具体是什么？", "那段经历里最难的部分是什么？"]},
        {"title": "踩过的坑与转折", "followups": ["最失败的一次尝试是什么？", "从中学到了什么？"]},
        {"title": "现在的方法论", "followups": ["如果重来一次会怎么做？", "给同行一条建议？"]},
    ]
    return {"opening": "欢迎%s，今天我们聊聊%s。" % (guest, topic), "sections": secs}


def predict(c, break_quote=False, break_timestamp=False, break_number=False):
    if c["kind"] == "outline":
        return outline(c)
    text = read_transcript(c)
    summ = summarize(text)
    if break_number:
        summ = summ[:SUMMARY_MAX - 12] + "（规模增长 999999 倍）"
    quotes = pick_quotes(text)
    if break_quote and quotes:
        q = quotes[0]
        quotes[0] = q[:-1] + ("。" if not q.endswith("。") else "。")  # 改标点=不再逐字
        quotes[0] = quotes[0].replace("我们", "咱们", 1) if "我们" in quotes[0] else quotes[0] + "（改写）"
    secs = extract_sections(text)
    if break_timestamp:
        secs = list(reversed(secs))
    return {"summary": summ, "sections": secs, "quotes": quotes}


def evaluate_case(c, break_quote=False, break_timestamp=False, break_number=False):
    out = predict(c, break_quote, break_timestamp, break_number)
    if c["kind"] == "outline":
        r = C.check_outline_output(c, out)
        return {"case_id": c["case_id"], "kind": c["kind"], "ok": r["ok"],
                "reason": r["reason"], "detail": r}
    text = read_transcript(c)
    r = C.check_summary_output(c, out, text)
    return {"case_id": c["case_id"], "kind": c["kind"], "ok": r["ok"],
            "reason": r["reason"], "detail": r,
            "summary_len": len(out["summary"]), "sections": len(out["sections"]),
            "quotes": len(out["quotes"])}


def aggregate(rows):
    n = len(rows)
    summ = [r for r in rows if r["kind"] == "summary"]
    outl = [r for r in rows if r["kind"] == "outline"]
    m = {"cases": n, "summary_cases": len(summ), "outline_cases": len(outl),
         "pass_rate": round(sum(1 for r in rows if r["ok"]) / n, 6) if n else 0.0,
         "summary_pass_rate": round(sum(1 for r in summ if r["ok"]) / len(summ), 6) if summ else 0.0,
         "outline_pass_rate": round(sum(1 for r in outl if r["ok"]) / len(outl), 6) if outl else 0.0,
         "fails": []}
    if m["pass_rate"] < 1.0:
        m["fails"].append("通过率 %.4f < 1.0（用例：%s）"
                          % (m["pass_rate"],
                             ", ".join(r["case_id"] for r in rows if not r["ok"])))
    return m


def write_report(m, rows, path_md, path_json):
    os.makedirs(os.path.dirname(path_md), exist_ok=True)
    L = ["# 个人 IP 内容助手评测报告 ip_content.podcast", "",
         "> 嘉宾与内容全部虚构，转写稿为原创合成；被测输出只进复核队列、不直接对外发送；"
         "AI 不计算金额。", "",
         "## 一、总体", "", "| 项 | 值 |", "|---|---|",
         "| 用例数 | %d（提纲 %d / 摘要 %d） |" % (m["cases"], m["outline_cases"], m["summary_cases"]),
         "| 通过率 | **%.4f** |" % m["pass_rate"],
         "| 提纲通过率 | %.4f |" % m["outline_pass_rate"],
         "| 摘要通过率 | %.4f |" % m["summary_pass_rate"], "",
         "## 二、三项程序化检查（摘要用例）", "",
         "| 用例 | 金句逐字 | 时间戳单调 | 摘要数字有据 | 结论 |", "|---|---|---|---|---|"]
    for r in rows:
        if r["kind"] != "summary":
            continue
        d = r["detail"]
        L.append("| %s | %s | %s | %s | %s |" % (
            r["case_id"], "✓" if d["quotes"]["ok"] else "✗",
            "✓" if d["timestamps"]["ok"] else "✗",
            "✓" if d["numbers"]["ok"] else "✗",
            "通过" if r["ok"] else "**未通过**"))
    L += ["", "## 三、未通过明细", ""]
    bad = [r for r in rows if not r["ok"]]
    if bad:
        for r in bad:
            L.append("- `%s`：%s" % (r["case_id"], r["reason"]))
    else:
        L.append("- 无")
    L += ["", "## 四、判定", "",
          "**%s**" % ("未达标：" + "；".join(m["fails"]) if m["fails"] else "全部通过"), ""]
    open(path_md, "w", encoding="utf-8").write("\n".join(L))
    json.dump({"metrics": m, "rows": rows}, open(path_json, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return path_md


def main(argv=None):
    ap = argparse.ArgumentParser(prog="ip_eval")
    ap.add_argument("--tag", default="v1")
    ap.add_argument("--break-quote", action="store_true")
    ap.add_argument("--break-timestamp", action="store_true")
    ap.add_argument("--break-number", action="store_true")
    a = ap.parse_args(argv)
    rows = [evaluate_case(c, a.break_quote, a.break_timestamp, a.break_number)
            for c in load_cases()]
    m = aggregate(rows)
    suffix = "" if not (a.break_quote or a.break_timestamp or a.break_number) else "_broken"
    md = os.path.join(REPORTS, "ip_%s%s.md" % (a.tag, suffix))
    write_report(m, rows, md, md[:-3] + ".json")
    print("cases=%d pass=%.4f summary=%.4f outline=%.4f"
          % (m["cases"], m["pass_rate"], m["summary_pass_rate"], m["outline_pass_rate"]))
    print("report=%s" % md)
    if m["fails"]:
        print("THRESHOLD NOT MET: " + "；".join(m["fails"])[:300])
        return 1
    print("THRESHOLD OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
