import { describe, it, expect } from 'vitest'
import { buildSuggestionJSON, type CaseDetail, type Mark } from '../api'

const C: CaseDetail = {
  id: '11111111-1111-1111-1111-111111111111',
  case_key: 'case-0001',
  input: '虚构问题',
  context: { turns: 1 },
  points: ['要点甲', '要点乙', '要点丙'],
  content_hash: 'abc123',
  review_status: 'pending',
  recent_runs: [],
  reviews: [],
}

describe('导出修改建议 JSON', () => {
  it('只导出已标记的要点，未标记的不出现', () => {
    const marks: Record<number, Mark> = { 1: { verdict: 'revise', comment: ' 举例不足 ' } }
    const r = buildSuggestionJSON(C, marks, 'u-1', '2026-11-26T00:00:00.000Z')
    expect(r.marked_points).toBe(1)
    expect(r.total_points).toBe(3)
    expect(r.suggestions).toHaveLength(1)
    expect(r.suggestions[0]).toMatchObject({ index: 1, point: '要点乙', verdict: 'revise', comment: '举例不足' })
  })

  it('页面不改用例文件：applied_to_file 必须为 false', () => {
    const r = buildSuggestionJSON(C, {}, 'u-1', '2026-11-26T00:00:00.000Z')
    expect(r.applied_to_file).toBe(false)
    expect(r.marked_points).toBe(0)
  })

  it('三种结论都能进建议：同意/需修改/删除', () => {
    const marks: Record<number, Mark> = {
      0: { verdict: 'approve', comment: '' },
      1: { verdict: 'revise', comment: '需补数据' },
      2: { verdict: 'remove', comment: '与要点甲重复' },
    }
    const r = buildSuggestionJSON(C, marks, 'u-1', '2026-11-26T00:00:00.000Z')
    expect(r.suggestions.map((s) => s.verdict)).toEqual(['approve', 'revise', 'remove'])
    expect(r.marked_points).toBe(3)
  })

  it('带出用例 content_hash，维护者据此判断建议是否过期', () => {
    const r = buildSuggestionJSON(C, {}, 'u-1', '2026-11-26T00:00:00.000Z')
    expect(r.content_hash).toBe('abc123')
    expect(r.schema).toBe('eval-case-suggestion/v1')
  })
})
