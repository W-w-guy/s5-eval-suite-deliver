import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import SuiteList from '../pages/SuiteList'
import CaseDetail from '../pages/CaseDetail'
import { REVIEW_PERM } from '../api'

const SUITES = {
  items: [
    { id: 's1', key: 'suite-a', name: '套件A', case_count: 3, reviewed_count: 1, latest_pass_rate: 0.5 },
    { id: 's2', key: 'suite-b', name: '套件B', case_count: 2, reviewed_count: 2, latest_pass_rate: 1 },
  ],
}
const CASE = {
  id: 'c1', case_key: 'case-0001', input: '虚构问题', context: {},
  points: ['要点甲', '要点乙'], content_hash: 'deadbeefdeadbeef',
  review_status: 'pending', recent_runs: [], reviews: [],
}


// TDesign 的 Button 渲染成 div，原生 toBeDisabled 对它无效——
// 真正的禁用信号是 class 上的 t-is-disabled 加上 disabled 属性，两处都要判。
function expectDisabled(el: HTMLElement, want: boolean) {
  const cls = el.className.includes('t-is-disabled')
  const attr = el.hasAttribute('disabled')
  expect({ cls, attr }).toEqual({ cls: want, attr: want })
}

function mockFetch(body: unknown) {
  const fn = vi.fn(async () => new Response(JSON.stringify(body), { status: 200 }))
  vi.stubGlobal('fetch', fn)
  return fn
}

const WHO_OK = { userId: 'aaaaaaaa-0000-0000-0000-000000000001', perms: REVIEW_PERM + ',eval.case.read' }
const WHO_NO = { userId: 'cccccccc-0000-0000-0000-000000000003', perms: 'eval.case.read' }

describe('套件列表页', () => {
  beforeEach(() => vi.restoreAllMocks())

  it('默认显示全部套件', async () => {
    mockFetch(SUITES)
    render(<MemoryRouter><SuiteList who={WHO_OK} /></MemoryRouter>)
    await waitFor(() => expect(screen.getByTestId('suite-count')).toHaveTextContent('共 2 个套件'))
  })

  it('「只看待复核」只留 review 未完成的套件（suite-b 已复核完，必须消失）', async () => {
    mockFetch(SUITES)
    render(<MemoryRouter><SuiteList who={WHO_OK} /></MemoryRouter>)
    await waitFor(() => expect(screen.getByTestId('suite-count')).toHaveTextContent('共 2 个套件'))
    await userEvent.click(screen.getByTestId('pending-filter'))
    await waitFor(() => expect(screen.getByTestId('suite-count')).toHaveTextContent('共 1 个套件'))
    expect(screen.queryByTestId('pending-suite-b')).toBeNull()
    expect(screen.getByTestId('pending-suite-a')).toBeInTheDocument()
  })
})

describe('用例详情页', () => {
  beforeEach(() => vi.restoreAllMocks())

  it('每条要点都有同意/需修改/删除三个操作', async () => {
    mockFetch(CASE)
    render(<MemoryRouter initialEntries={['/eval/suites/suite-a/cases/case-0001']}>
      <Routes><Route path="/eval/suites/:suiteKey/cases/:caseKey" element={<CaseDetail who={WHO_OK} />} /></Routes>
    </MemoryRouter>)
    await waitFor(() => expect(screen.getByTestId('point-0')).toBeInTheDocument())
    for (const i of [0, 1]) {
      expect(screen.getByTestId(`point-${i}-approve`)).toBeInTheDocument()
      expect(screen.getByTestId(`point-${i}-revise`)).toBeInTheDocument()
      expect(screen.getByTestId(`point-${i}-remove`)).toBeInTheDocument()
    }
  })

  it('无 eval.case.review 权限时三个操作与提交/导出全部禁用', async () => {
    mockFetch(CASE)
    render(<MemoryRouter initialEntries={['/eval/suites/suite-a/cases/case-0001']}>
      <Routes><Route path="/eval/suites/:suiteKey/cases/:caseKey" element={<CaseDetail who={WHO_NO} />} /></Routes>
    </MemoryRouter>)
    await waitFor(() => expect(screen.getByTestId('point-0')).toBeInTheDocument())
    expectDisabled(screen.getByTestId('point-0-approve'), true)
    expectDisabled(screen.getByTestId('point-0-remove'), true)
    expectDisabled(screen.getByTestId('submit-review'), true)
    expectDisabled(screen.getByTestId('export-suggestion'), true)
    expect(screen.getByTestId('no-perm-hint')).toBeInTheDocument()
  })

  it('反向对照：有权限时同样的按钮必须可用（否则上一条断言恒真）', async () => {
    mockFetch(CASE)
    render(<MemoryRouter initialEntries={['/eval/suites/suite-a/cases/case-0001']}>
      <Routes><Route path="/eval/suites/:suiteKey/cases/:caseKey" element={<CaseDetail who={WHO_OK} />} /></Routes>
    </MemoryRouter>)
    await waitFor(() => expect(screen.getByTestId('point-0')).toBeInTheDocument())
    expectDisabled(screen.getByTestId('point-0-approve'), false)
    expectDisabled(screen.getByTestId('submit-review'), false)
    expect(screen.queryByTestId('no-perm-hint')).toBeNull()
  })

  it('点「需修改」后计数变化（真的点了，不是静态渲染）', async () => {
    mockFetch(CASE)
    render(<MemoryRouter initialEntries={['/eval/suites/suite-a/cases/case-0001']}>
      <Routes><Route path="/eval/suites/:suiteKey/cases/:caseKey" element={<CaseDetail who={WHO_OK} />} /></Routes>
    </MemoryRouter>)
    await waitFor(() => expect(screen.getByTestId('point-0')).toBeInTheDocument())
    expect(screen.getByTestId('marked-count')).toHaveTextContent('已标记 0 / 2 条要点')
    await userEvent.click(screen.getByTestId('point-1-revise'))
    await waitFor(() => expect(screen.getByTestId('marked-count')).toHaveTextContent('已标记 1 / 2 条要点'))
  })
})
